# PRMR_Simulation

This repository contains the simulation code developed for the course "Programmierung und Regelung für Mensch-Roboterinteraktion (IN2308)" at TUM, implemented in MATLAB.

The Simulink results are provided in folders named PRMR_Simu_X_X. For best compatibility, please use **MATLAB R2024b or earlier**.  
Later versions may cause unexpected compatibility issues.

Before running any Simulink model, please execute init.m in the library folder to load the required simulation parameters, which can be adjusted as needed. The simulation task description can be found in the PDF titled tutorial.
